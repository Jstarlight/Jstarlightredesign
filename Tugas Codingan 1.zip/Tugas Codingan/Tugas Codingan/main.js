// Fungsi untuk memulai animasi saat menu populer muncul
function startAnimation() {
    var menuPopuler = document.querySelector('.menu-populer h1');
    menuPopuler.classList.add('animate-slideIn'); // Menambahkan kelas untuk memulai animasi
}

// Fungsi untuk menangani peristiwa scroll
function handleScroll() {
    var menuPopuler = document.querySelector('.menu-populer');
    var bounding = menuPopuler.getBoundingClientRect(); // Mendapatkan bounding box elemen menu populer

    // Memulai animasi jika elemen menu populer terlihat dalam jendela penjelajah
    if (
        bounding.top >= 0 &&
        bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight)
    ) {
        startAnimation(); // Panggil fungsi untuk memulai animasi
    }
}

